import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner ps = new Scanner(System.in);
		String s = ps.next(),s1 = ps.next();
		int sum = 0;
		for(int i = 0 ;i<s.length();i++){
		    char c = s.charAt(i);
		    for(int j = 0;j<s1.length();j++){
		        char ch = s1.charAt(j);
		        if(c==ch)
		        sum++;
		    }
		}
		if(sum>=s1.length())
		System.out.print("Yes");
		else
		System.out.print("No");
	}
}

